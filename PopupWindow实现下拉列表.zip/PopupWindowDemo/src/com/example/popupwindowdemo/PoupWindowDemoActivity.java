package com.example.popupwindowdemo;


import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class PoupWindowDemoActivity extends Activity {

	private PopupWindow popupWindow;

	private ListView lv_group;

	private View view;

	private View top_title;

	private TextView tvtitle;

	private List<String> groups;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);

		top_title = this.findViewById(R.id.top_title);

		tvtitle = (TextView) top_title.findViewById(R.id.tvtitle);

		tvtitle.setText("����û��·");

		tvtitle.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				showWindow(v);
			}
		});

	}

	
	private void showWindow(View parent) {

		if (popupWindow == null) {
			LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

			view = layoutInflater.inflate(R.layout.group_list, null);

			lv_group = (ListView) view.findViewById(R.id.lvGroup);
			// ��������
			groups = new ArrayList<String>();
			groups.add("ȫ��");
			groups.add("�ҵ�΢��");
			groups.add("����");
			groups.add("����");
			groups.add("ͬѧ");
			groups.add("����");
			groups.add("İ����");

			GroupAdapter groupAdapter = new GroupAdapter(this, groups);
			lv_group.setAdapter(groupAdapter);
			// ����һ��PopuWidow����
			popupWindow = new PopupWindow(view, 300, 350);
		}

		// ʹ��ۼ�
		popupWindow.setFocusable(true);
		// ����������������ʧ
		popupWindow.setOutsideTouchable(true);

		// �����Ϊ�˵��������Back��Ҳ��ʹ����ʧ�����Ҳ�����Ӱ����ı���
		popupWindow.setBackgroundDrawable(new BitmapDrawable());
		WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		// ��ʾ��λ��Ϊ:��Ļ�Ŀ��ȵ�һ��-PopupWindow�ĸ߶ȵ�һ��
		int xPos = windowManager.getDefaultDisplay().getWidth() / 2
				- popupWindow.getWidth() / 2;
		Log.i("coder", "xPos:" + xPos);

		popupWindow.showAsDropDown(parent, xPos, 0);

		lv_group.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> adapterView, View view,
					int position, long id) {

				Toast.makeText(PoupWindowDemoActivity.this,
						groups.get(position), 1000)
						.show();

				if (popupWindow != null) {
					popupWindow.dismiss();
				}
			}
		});
	}
}